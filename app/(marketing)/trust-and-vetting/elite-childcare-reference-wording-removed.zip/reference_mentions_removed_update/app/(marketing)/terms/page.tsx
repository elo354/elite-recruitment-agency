import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms & Conditions | Elite Childcare Recruitment",
  description: "Terms and conditions for Elite Childcare Recruitment's childcare recruitment service.",
};

const SECTIONS = [
  { title: "1. Introduction", body: "These Terms & Conditions apply to the use of Elite Childcare Recruitment and our childcare recruitment services. By contacting us, submitting a form, applying as a candidate, or requesting a placement, you agree to use our service honestly and professionally. Elite Childcare Recruitment LTD, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ, United Kingdom." },
  { title: "2. Definitions", body: "\"Client\" means a family, parent, guardian or household seeking childcare support. \"Candidate\" means a nanny, maternity nurse, night maternity nurse, newborn care specialist or other childcare professional applying for placement. \"Agency\" means Elite Childcare Recruitment." },
  { title: "3. Agency Services", body: "We provide recruitment support by introducing suitable childcare candidates to Clients. Our service acts as an introduction-only agency and we do not employ Candidates directly unless expressly agreed otherwise. Following an introduction, the Client and Candidate are responsible for agreeing the terms of engagement, remuneration and contractual arrangements between themselves. Our service may include consultation, candidate review, remote communication, interview coordination and placement support." },
  { title: "4. Client Responsibilities", body: "Clients agree to provide accurate information about their requirements, to treat Candidates fairly and professionally, to comply with all relevant legal and employment obligations applicable to the engagement, and to pay the agreed placement fee upon confirmation of a placement." },
  { title: "5. Candidate Responsibilities", body: "Candidates agree to provide accurate and honest information about their experience, qualifications and right to work or travel where relevant, to cooperate with our recruitment and suitability-review process, and to conduct themselves professionally throughout the recruitment process." },
  { title: "6. DBS Checks", body: "It is the Candidate's responsibility to obtain and hold any DBS or equivalent background check required for the role. Clients are responsible for reviewing the documentation provided and satisfying themselves that the Candidate is suitable before engagement. Unless expressly agreed otherwise in writing, the Agency does not arrange or carry out DBS checks and accepts no liability for a Client's decision to engage a Candidate." },
  { title: "7. Fees", body: "Placement fees are payable by the Client. For permanent nanny and private household childcare placements, the Agency fee is 12% of the Candidate's agreed annual gross salary. For Maternity Nurse, Day Maternity Nurse, Night Maternity Nurse and specialist newborn-care placements, the Agency fee is 12% of the Candidate's agreed annual gross salary. Placement fees become payable once a Client confirms, verbally or in writing, that they wish to engage a Candidate introduced by the Agency, unless otherwise agreed in writing. Agency placement fees are separate from the Candidate's remuneration and are not deducted from the Candidate's pay." },
  { title: "8. International Placements", body: "Where a role involves international travel or relocation, the Client and Candidate are responsible for agreeing travel arrangements, accommodation, expenses, insurance, visas, work permissions and any other requirements relevant to the destination. The Agency may assist with coordination but does not guarantee immigration, visa or work-permission eligibility." },
  { title: "9. Privacy", body: "We handle personal data in accordance with our Privacy Policy and applicable UK data protection law." },
  { title: "10. Contact", body: "Questions about these Terms can be sent to eliterecruitmentagencies@gmail.com." },
];

export default function TermsPage() {
  return (
    <div className="px-[7%] py-20">
      <div className="max-w-2xl mx-auto text-center mb-14">
        <div className="label justify-center flex mb-4">Terms</div>
        <h1 className="font-serif text-4xl sm:text-5xl text-navy mb-6">Terms &amp; Conditions</h1>
        <p className="text-ink/70 leading-relaxed">Please read our agency terms carefully.</p>
      </div>

      <div className="max-w-2xl mx-auto flex flex-col gap-8">
        {SECTIONS.map((section) => (
          <div key={section.title}>
            <h2 className="font-serif text-xl text-navy mb-2">{section.title}</h2>
            <p className="text-sm text-ink/70 leading-relaxed">{section.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
