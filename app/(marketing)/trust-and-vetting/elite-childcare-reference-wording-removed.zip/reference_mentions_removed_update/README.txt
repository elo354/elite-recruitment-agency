Elite Childcare Recruitment - Reference wording removal update

This update removes public-facing claims that the agency verifies or checks candidate references.
It preserves the current 12% fee wording in the Terms & Conditions.

Files changed:
- app/(marketing)/page.tsx
- app/(marketing)/faq/page.tsx
- app/(marketing)/for-nannies/page.tsx
- app/(marketing)/how-it-works/page.tsx
- app/(marketing)/policies/page.tsx
- app/(marketing)/privacy/page.tsx
- app/(marketing)/terms/page.tsx
- app/(marketing)/thank-you/page.tsx
- app/(marketing)/trust-and-vetting/page.tsx
- app/nanny/apply/page.tsx
